
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'python_backend.dart';
import 'premium_service.dart';
import 'account_service.dart';
import 'api_config.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await ApiConfig.load();
  runApp(const PythonApp());
}

class PythonApp extends StatefulWidget {
  const PythonApp({super.key});

  @override
  State<PythonApp> createState() => _PythonAppState();
}

class _PythonAppState extends State<PythonApp> {
  bool arabic = true;
  int points = 0;
  late PremiumService premiumService;
  bool accountLoading = true;
  bool loggedIn = false;

  @override
  void initState() {
    super.initState();
    premiumService = PremiumService();
    _load();
    _checkAccount();
  }

  Future<void> _checkAccount() async {
    final token = await AccountService.token();
    if (!mounted) return;
    setState(() {
      loggedIn = token != null && token.isNotEmpty;
      accountLoading = false;
    });
  }

  Future<void> _onLoggedIn() async {
    if (!mounted) return;
    setState(() => loggedIn = true);
  }

  Future<void> _logout() async {
    await AccountService.logout();
    if (!mounted) return;
    setState(() => loggedIn = false);
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      arabic = p.getBool('arabic') ?? true;
      points = p.getInt('points') ?? 0;
    });
  }

  Future<void> setLanguage(bool value) async {
    final p = await SharedPreferences.getInstance();
    await p.setBool('arabic', value);
    if (!mounted) return;
    setState(() => arabic = value);
  }

  Future<void> addPoints(int value) async {
    final p = await SharedPreferences.getInstance();
    points += value;
    await p.setInt('points', points);
    if (!mounted) return;
    setState(() {});
  }

  @override
  void dispose() {
    premiumService.dispose();
    super.dispose();
  }

  Widget build(BuildContext context) {
    if (accountLoading) {
      return const MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Scaffold(body: Center(child: CircularProgressIndicator())),
      );
    }

    if (!loggedIn) {
      return MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Python',
        theme: ThemeData(
          brightness: Brightness.dark,
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF2196F3),
            brightness: Brightness.dark,
          ),
          useMaterial3: true,
        ),
        home: AuthPage(arabic: arabic, onLoggedIn: _onLoggedIn),
      );
    }

    return AnimatedBuilder(
      animation: premiumService,
      builder: (context, _) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Python',
        theme: ThemeData(
          brightness: Brightness.dark,
          scaffoldBackgroundColor: const Color(0xFF061126),
          colorScheme: ColorScheme.fromSeed(
            seedColor: const Color(0xFF2196F3),
            brightness: Brightness.dark,
          ),
          fontFamily: 'sans',
          useMaterial3: true,
        ),
        home: Directionality(
          textDirection: arabic ? TextDirection.rtl : TextDirection.ltr,
          child: HomePage(
            arabic: arabic,
            points: points,
            onLanguageChanged: setLanguage,
            onPoints: addPoints,
            premiumService: premiumService,
            onLogout: _logout,
          ),
        ),
      ),
    );
  }
}

class AuthPage extends StatefulWidget {
  final bool arabic;
  final Future<void> Function() onLoggedIn;
  const AuthPage({super.key, required this.arabic, required this.onLoggedIn});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool registerMode = true;
  bool busy = false;
  String? error;

  String t(String ar, String en) => widget.arabic ? ar : en;

  Future<void> submit() async {
    setState(() {
      busy = true;
      error = null;
    });
    try {
      if (registerMode) {
        await AccountService.register(email.text, password.text);
      } else {
        await AccountService.login(email.text, password.text);
      }
      await widget.onLoggedIn();
    } catch (e) {
      setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  void dispose() {
    email.dispose();
    password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: widget.arabic ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 460),
                child: Column(
                  children: [
                    const PythonLogo(size: 82),
                    const SizedBox(height: 16),
                    Text(
                      'Python',
                      style: const TextStyle(
                        fontSize: 34,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      t(
                        'أنشئ حسابك ثم اختر اشتراك Premium لفتح المميزات',
                        'Create your account, then choose a Premium subscription to unlock features',
                      ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 28),
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(20),
                        child: Column(
                          children: [
                            Text(
                              t(
                                registerMode ? 'إنشاء حساب' : 'تسجيل الدخول',
                                registerMode ? 'Create account' : 'Log in',
                              ),
                              style: const TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            const SizedBox(height: 18),
                            TextField(
                              controller: email,
                              keyboardType: TextInputType.emailAddress,
                              decoration: InputDecoration(
                                labelText: t('البريد الإلكتروني', 'Email'),
                              ),
                            ),
                            const SizedBox(height: 12),
                            TextField(
                              controller: password,
                              obscureText: true,
                              decoration: InputDecoration(
                                labelText: t('كلمة المرور', 'Password'),
                              ),
                            ),
                            if (error != null) ...[
                              const SizedBox(height: 12),
                              Text(
                                error!,
                                style: const TextStyle(color: Colors.redAccent),
                              ),
                            ],
                            const SizedBox(height: 20),
                            SizedBox(
                              width: double.infinity,
                              child: FilledButton(
                                onPressed: busy ? null : submit,
                                child: Text(
                                  busy
                                      ? t('جاري التنفيذ...', 'Please wait...')
                                      : t(
                                          registerMode
                                              ? 'إنشاء الحساب'
                                              : 'دخول',
                                          registerMode
                                              ? 'Create account'
                                              : 'Log in',
                                        ),
                                ),
                              ),
                            ),
                            TextButton(
                              onPressed: busy
                                  ? null
                                  : () => setState(() {
                                      registerMode = !registerMode;
                                      error = null;
                                    }),
                              child: Text(
                                t(
                                  registerMode
                                      ? 'لدي حساب بالفعل'
                                      : 'إنشاء حساب جديد',
                                  registerMode
                                      ? 'I already have an account'
                                      : 'Create a new account',
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final bool arabic;
  final int points;
  final ValueChanged<bool> onLanguageChanged;
  final Future<void> Function(int) onPoints;
  final PremiumService premiumService;
  final VoidCallback onLogout;

  const HomePage({
    super.key,
    required this.arabic,
    required this.points,
    required this.onLanguageChanged,
    required this.onPoints,
    required this.premiumService,
    required this.onLogout,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int tab = 0;

  String t(String ar, String en) => widget.arabic ? ar : en;

  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(),
      LearnPage(arabic: widget.arabic, onPoints: widget.onPoints),
      ProgressPage(arabic: widget.arabic, points: widget.points),
      SettingsPage(
        arabic: widget.arabic,
        onLanguageChanged: widget.onLanguageChanged,
        onLogout: widget.onLogout,
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: Row(
          children: [
            const PythonLogo(size: 34),
            const SizedBox(width: 10),
            Text('Python', style: const TextStyle(fontWeight: FontWeight.w800)),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Premium',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => PremiumPage(
                  arabic: widget.arabic,
                  service: widget.premiumService,
                ),
              ),
            ),
            icon: Icon(
              widget.premiumService.premium
                  ? Icons.workspace_premium
                  : Icons.lock_outline,
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14),
            child: Center(
              child: Text(
                '⭐ ${widget.points}',
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
          ),
        ],
      ),
      body: SafeArea(child: pages[tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: [
          NavigationDestination(
            icon: const Icon(Icons.home_outlined),
            selectedIcon: const Icon(Icons.home),
            label: t('الرئيسية', 'Home'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.menu_book_outlined),
            selectedIcon: const Icon(Icons.menu_book),
            label: t('التعلم', 'Learn'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.emoji_events_outlined),
            selectedIcon: const Icon(Icons.emoji_events),
            label: t('تقدمي', 'Progress'),
          ),
          NavigationDestination(
            icon: const Icon(Icons.settings_outlined),
            selectedIcon: const Icon(Icons.settings),
            label: t('الإعدادات', 'Settings'),
          ),
        ],
      ),
    );
  }

  Widget _home() {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        if (!widget.premiumService.premium)
          Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: InkWell(
              borderRadius: BorderRadius.circular(22),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => PremiumPage(
                    arabic: widget.arabic,
                    service: widget.premiumService,
                  ),
                ),
              ),
              child: Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(22),
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFFA000), Color(0xFFE65100)],
                  ),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.workspace_premium, size: 34),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        t('افتح Python Premium 🚀', 'Unlock Python Premium 🚀'),
                        style: const TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 17,
                        ),
                      ),
                    ),
                    const Icon(Icons.arrow_forward_ios, size: 16),
                  ],
                ),
              ),
            ),
          ),
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            gradient: const LinearGradient(
              colors: [Color(0xFF087CF5), Color(0xFF5B2CFF)],
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                t(
                  'ابدأ رحلتك في تعلم بايثون 🚀',
                  'Start your Python journey 🚀',
                ),
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                t(
                  'تعلم، اكتب، شغّل، واكتشف أخطاء الكود في مكان واحد.',
                  'Learn, code, run and debug in one place.',
                ),
                style: const TextStyle(fontSize: 15, height: 1.5),
              ),
              const SizedBox(height: 18),
              FilledButton.icon(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => LearnPage(
                      arabic: widget.arabic,
                      onPoints: widget.onPoints,
                    ),
                  ),
                ),
                icon: const Icon(Icons.play_arrow),
                label: Text(t('ابدأ أول درس', 'Start first lesson')),
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 1.12,
          children: [
            FeatureCard(
              icon: Icons.menu_book,
              title: t('تعلم Python', 'Learn Python'),
              subtitle: t('من الصفر', 'From zero'),
              color: const Color(0xFF6C4BFF),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => LearnPage(
                    arabic: widget.arabic,
                    onPoints: widget.onPoints,
                  ),
                ),
              ),
            ),
            FeatureCard(
              icon: Icons.camera_alt,
              title: t('صوّر الكود', 'Scan Code'),
              subtitle: t('حلل صورة الكود', 'Analyze an image'),
              color: const Color(0xFF16C784),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const ScannerPage()),
              ),
            ),
            FeatureCard(
              icon: Icons.code,
              title: t('محرر الأكواد', 'Code Editor'),
              subtitle: t('اكتب وجرب', 'Write & test'),
              color: const Color(0xFF1597FF),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => EditorPage(
                    arabic: widget.arabic,
                    onPoints: widget.onPoints,
                  ),
                ),
              ),
            ),
            FeatureCard(
              icon: Icons.bug_report,
              title: t('اكتشف الأخطاء', 'Debug Code'),
              subtitle: t('افهم الخطأ', 'Understand errors'),
              color: const Color(0xFFFF8A00),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => EditorPage(
                    arabic: widget.arabic,
                    onPoints: widget.onPoints,
                    debugMode: true,
                  ),
                ),
              ),
            ),
            FeatureCard(
              icon: Icons.smart_toy,
              title: t('المدرس الذكي', 'AI Tutor'),
              subtitle: t('اسأل وتعلم', 'Ask & learn'),
              color: const Color(0xFFE83EFF),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => TutorPage(arabic: widget.arabic),
                ),
              ),
            ),
            FeatureCard(
              icon: Icons.workspace_premium,
              title: t('تحديات', 'Challenges'),
              subtitle: t('اختبر نفسك', 'Test yourself'),
              color: const Color(0xFF00BFA6),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ChallengePage(
                    arabic: widget.arabic,
                    onPoints: widget.onPoints,
                  ),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class LearnPage extends StatelessWidget {
  final bool arabic;
  final Future<void> Function(int) onPoints;
  const LearnPage({super.key, required this.arabic, required this.onPoints});

  String t(String ar, String en) => arabic ? ar : en;

  final List<Map<String, String>> lessons = const [
    {
      'ar': 'ما هي Python؟',
      'en': 'What is Python?',
      'descAr': 'تعرف على اللغة واستخداماتها.',
      'descEn': 'Learn what Python is and where it is used.',
    },
    {
      'ar': 'المتغيرات وأنواع البيانات',
      'en': 'Variables & Data Types',
      'descAr': 'النصوص والأرقام والقيم المنطقية.',
      'descEn': 'Strings, numbers and booleans.',
    },
    {
      'ar': 'الشروط',
      'en': 'Conditions',
      'descAr': 'if / elif / else بطريقة سهلة.',
      'descEn': 'if / elif / else made easy.',
    },
    {
      'ar': 'الحلقات التكرارية',
      'en': 'Loops',
      'descAr': 'for و while مع أمثلة.',
      'descEn': 'for and while with examples.',
    },
    {
      'ar': 'القوائم والقواميس',
      'en': 'Lists & Dictionaries',
      'descAr': 'تخزين وتنظيم البيانات.',
      'descEn': 'Store and organize data.',
    },
    {
      'ar': 'الدوال',
      'en': 'Functions',
      'descAr': 'اكتب كودًا منظمًا وقابلًا لإعادة الاستخدام.',
      'descEn': 'Write reusable, organized code.',
    },
    {
      'ar': 'OOP',
      'en': 'OOP',
      'descAr': 'مقدمة في البرمجة الكائنية.',
      'descEn': 'Introduction to object-oriented programming.',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Text(
          t('دروس Python', 'Python Lessons'),
          style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 6),
        Text(
          t(
            'خطوة بخطوة من المبتدئ للمحترف.',
            'Step by step from beginner to advanced.',
          ),
        ),
        const SizedBox(height: 18),
        ...List.generate(lessons.length, (i) {
          final l = lessons[i];
          return Card(
            margin: const EdgeInsets.only(bottom: 12),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.blue.withValues(alpha: .18),
                child: Text('${i + 1}'),
              ),
              title: Text(
                t(l['ar']!, l['en']!),
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Text(t(l['descAr']!, l['descEn']!)),
              trailing: const Icon(Icons.chevron_right),
              onTap: () async {
                await onPoints(10);
                if (!context.mounted) return;
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => LessonDetailPage(
                      arabic: arabic,
                      index: i,
                      title: t(l['ar']!, l['en']!),
                    ),
                  ),
                );
              },
            ),
          );
        }),
      ],
    );
  }
}

class LessonDetailPage extends StatelessWidget {
  final bool arabic;
  final int index;
  final String title;

  const LessonDetailPage({
    super.key,
    required this.arabic,
    required this.index,
    required this.title,
  });

  String t(String ar, String en) => arabic ? ar : en;

  @override
  Widget build(BuildContext context) {
    final contents = [
      [
        'Python هي لغة برمجة سهلة وقوية تُستخدم في تطبيقات كثيرة مثل الويب والبيانات والذكاء الاصطناعي.',
        'Python is a simple and powerful programming language used for web, data, AI and many other applications.',
        'print("Hello Python")',
      ],
      [
        'المتغير هو اسم نستخدمه لحفظ قيمة. Python تحدد نوع البيانات تلقائيًا.',
        'A variable is a name used to store a value. Python detects the data type automatically.',
        'name = "Ahmed"\nage = 23\nprint(name, age)',
      ],
      [
        'نستخدم if لاتخاذ قرار بناءً على شرط.',
        'Use if to make a decision based on a condition.',
        'age = 20\nif age >= 18:\n    print("Adult")',
      ],
      [
        'الحلقة for تكرر مجموعة أوامر عددًا من المرات.',
        'A for loop repeats instructions over a sequence.',
        'for i in range(5):\n    print(i)',
      ],
      [
        'القائمة تخزن عدة قيم، والقاموس يخزن أزواج مفتاح وقيمة.',
        'A list stores multiple values; a dictionary stores key-value pairs.',
        'names = ["Ali", "Sara"]\nuser = {"name": "Ali", "age": 23}',
      ],
      [
        'الدالة مجموعة أوامر يمكن استدعاؤها أكثر من مرة.',
        'A function is a reusable block of code.',
        'def greet(name):\n    return "Hello " + name\n\nprint(greet("Ali"))',
      ],
      [
        'OOP طريقة لتنظيم البرامج باستخدام الكلاسات والكائنات.',
        'OOP organizes programs using classes and objects.',
        'class Person:\n    def __init__(self, name):\n        self.name = name',
      ],
    ];

    final c = contents[index.clamp(0, contents.length - 1)];

    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Text(
            t(c[0], c[1]),
            style: const TextStyle(fontSize: 18, height: 1.7),
          ),
          const SizedBox(height: 20),
          CodeBox(code: c[2]),
          const SizedBox(height: 20),
          FilledButton.icon(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => EditorPage(arabic: arabic)),
            ),
            icon: const Icon(Icons.code),
            label: Text(t('جرّب الكود', 'Try the code')),
          ),
        ],
      ),
    );
  }
}

class EditorPage extends StatefulWidget {
  final bool arabic;
  final Future<void> Function(int)? onPoints;
  final bool debugMode;

  const EditorPage({
    super.key,
    required this.arabic,
    this.onPoints,
    this.debugMode = false,
  });

  @override
  State<EditorPage> createState() => _EditorPageState();
}

class _EditorPageState extends State<EditorPage> {
  late final TextEditingController controller;
  String result = '';

  String t(String ar, String en) => widget.arabic ? ar : en;

  @override
  void initState() {
    super.initState();
    controller = TextEditingController(
      text: 'name = "Python"\nprint("Hello", name)\n',
    );
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  void analyze() async {
    final code = controller.text;
    setState(() {
      result = t('جاري فحص وتشغيل الكود...', 'Checking and running code...');
    });

    try {
      final data = await PythonBackend.execute(code);
      final ok = data['ok'] == true;
      final stdout = (data['stdout'] ?? '').toString();
      final stderr = (data['stderr'] ?? '').toString();
      if (!mounted) return;
      setState(() {
        result = ok
            ? t(
                '✅ تم التشغيل بنجاح:\n$stdout',
                '✅ Execution succeeded:\n$stdout',
              )
            : t('❌ يوجد خطأ:\n$stderr', '❌ Error:\n$stderr');
      });
      if (ok) await widget.onPoints?.call(10);
    } catch (e) {
      try {
        final ai = await PythonBackend.askAI(
          prompt: t(
            'حلل الكود وحدد الأخطاء واشرحها للمبتدئ وأعطني النسخة المصححة.',
            'Analyze this code, find errors, explain them to a beginner, and provide corrected code.',
          ),
          language: widget.arabic ? 'ar' : 'en',
          code: code,
        );
        if (!mounted) return;
        setState(() => result = ai);
      } catch (aiError) {
        if (!mounted) return;
        setState(
          () => result = t(
            'تعذر الاتصال بمحرك Python والذكاء الاصطناعي. تأكد من تشغيل الخادم وضبط عنوانه.',
            'Could not connect to the Python engine or AI. Check that the backend is running and its URL is configured.',
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(t('محرر الأكواد', 'Code Editor')),
        actions: [
          IconButton(
            tooltip: t('تحليل', 'Analyze'),
            onPressed: analyze,
            icon: const Icon(Icons.bug_report),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Container(
              margin: const EdgeInsets.fromLTRB(12, 12, 12, 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFF020916),
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: Colors.blue.withValues(alpha: .25)),
              ),
              child: TextField(
                controller: controller,
                expands: true,
                maxLines: null,
                minLines: null,
                style: const TextStyle(
                  fontFamily: 'monospace',
                  fontSize: 15,
                  height: 1.6,
                ),
                decoration: InputDecoration(
                  border: InputBorder.none,
                  hintText: t(
                    'اكتب كود Python هنا...',
                    'Write Python code here...',
                  ),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Expanded(
                  child: FilledButton.icon(
                    onPressed: analyze,
                    icon: const Icon(Icons.play_arrow),
                    label: Text(t('تحليل وتشغيل', 'Analyze & Run')),
                  ),
                ),
                const SizedBox(width: 10),
                IconButton.filledTonal(
                  onPressed: () => controller.clear(),
                  icon: const Icon(Icons.delete_outline),
                ),
              ],
            ),
          ),
          if (result.isNotEmpty)
            Container(
              width: double.infinity,
              margin: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: result.startsWith('✅')
                    ? Colors.green.withValues(alpha: .12)
                    : Colors.red.withValues(alpha: .12),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Text(result, style: const TextStyle(height: 1.5)),
            ),
        ],
      ),
    );
  }
}

class ScannerPage extends StatefulWidget {
  const ScannerPage({super.key});

  @override
  State<ScannerPage> createState() => _ScannerPageState();
}

class _ScannerPageState extends State<ScannerPage> {
  String text = '';
  Uint8List? imageBytes;
  String imageMime = 'image/jpeg';
  bool loading = false;

  Future<void> scan() async {
    final picker = ImagePicker();
    final image = await picker.pickImage(source: ImageSource.camera);
    if (image == null) return;

    if (!mounted) return;
    setState(() => loading = true);
    final recognizer = TextRecognizer(script: TextRecognitionScript.latin);
    try {
      final bytes = await image.readAsBytes();
      final input = InputImage.fromFilePath(image.path);
      final result = await recognizer.processImage(input);
      if (!mounted) return;
      setState(() {
        text = result.text;
        imageBytes = bytes;
        imageMime = image.mimeType ?? 'image/jpeg';
      });
    } finally {
      await recognizer.close();
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Scan Code / تصوير الكود')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            height: 220,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(26),
              gradient: const LinearGradient(
                colors: [Color(0xFF0D6EFD), Color(0xFF6C4BFF)],
              ),
            ),
            child: const Center(child: Icon(Icons.document_scanner, size: 85)),
          ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: loading ? null : scan,
            icon: const Icon(Icons.camera_alt),
            label: Text(loading ? 'Reading...' : 'تصوير وتحليل الكود'),
          ),
          if (text.isNotEmpty) ...[
            const SizedBox(height: 18),
            const Text(
              'Extracted Code',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
            const SizedBox(height: 8),
            CodeBox(code: text),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: () async {
                try {
                  final answer = await PythonBackend.askAI(
                    prompt:
                        'اقرأ الكود من الصورة، استخرج الكود إن أمكن، ثم اكتشف الأخطاء واشرحها وأعطني الكود المصحح.',
                    language: 'ar',
                    code: text,
                    imageBytes: imageBytes,
                    imageMime: imageMime,
                  );
                  if (!context.mounted) return;
                  showDialog(
                    context: context,
                    builder: (_) => AlertDialog(
                      title: const Text('تحليل الذكاء الاصطناعي'),
                      content: SingleChildScrollView(child: Text(answer)),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('إغلاق'),
                        ),
                      ],
                    ),
                  );
                } catch (e) {
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('تعذر الاتصال بالذكاء الاصطناعي'),
                    ),
                  );
                }
              },
              icon: const Icon(Icons.auto_awesome),
              label: const Text('حلّل وصحّح بالذكاء الاصطناعي'),
            ),
            const SizedBox(height: 12),
            const Text(
              'يمكن إرسال النص المستخرج إلى محرك Python أو المدرس الذكي.',
              style: TextStyle(height: 1.5),
            ),
          ],
        ],
      ),
    );
  }
}

class TutorPage extends StatefulWidget {
  final bool arabic;
  const TutorPage({super.key, required this.arabic});

  @override
  State<TutorPage> createState() => _TutorPageState();
}

class _TutorPageState extends State<TutorPage> {
  final controller = TextEditingController();
  final messages = <Map<String, String>>[];

  String t(String ar, String en) => widget.arabic ? ar : en;

  Future<void> ask() async {
    final q = controller.text.trim();
    if (q.isEmpty) return;
    setState(() {
      messages.add({'who': 'user', 'text': q});
      messages.add({'who': 'bot', 'text': t('جاري التفكير...', 'Thinking...')});
      controller.clear();
    });

    try {
      final answer = await PythonBackend.askAI(
        prompt: q,
        language: widget.arabic ? 'ar' : 'en',
      );
      setState(() {
        messages.removeLast();
        messages.add({'who': 'bot', 'text': answer});
      });
    } catch (e) {
      setState(() {
        messages.removeLast();
        messages.add({
          'who': 'bot',
          'text': t(
            'لم أستطع الاتصال بالمدرس الذكي. شغّل backend واضبط GEMINI_API_KEY.',
            'I could not reach the AI tutor. Start the backend and configure GEMINI_API_KEY.',
          ),
        });
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(t('المدرس الذكي', 'AI Tutor'))),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const CircleAvatar(
                  radius: 34,
                  child: Icon(Icons.smart_toy, size: 38),
                ),
                const SizedBox(height: 12),
                Center(
                  child: Text(
                    t('اسألني عن Python', 'Ask me about Python'),
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                const SizedBox(height: 18),
                ...messages.map(
                  (m) => Align(
                    alignment: m['who'] == 'user'
                        ? AlignmentDirectional.centerEnd
                        : AlignmentDirectional.centerStart,
                    child: Container(
                      constraints: const BoxConstraints(maxWidth: 330),
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: m['who'] == 'user'
                            ? Colors.blue.withValues(alpha: .25)
                            : Colors.white.withValues(alpha: .07),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Text(
                        m['text']!,
                        style: const TextStyle(height: 1.5),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: controller,
                      decoration: InputDecoration(
                        hintText: t('اكتب سؤالك...', 'Ask a question...'),
                        filled: true,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(18),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: ask,
                    icon: const Icon(Icons.send),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class ChallengePage extends StatefulWidget {
  final bool arabic;
  final Future<void> Function(int) onPoints;
  const ChallengePage({
    super.key,
    required this.arabic,
    required this.onPoints,
  });

  @override
  State<ChallengePage> createState() => _ChallengePageState();
}

class _ChallengePageState extends State<ChallengePage> {
  bool done = false;

  String t(String ar, String en) => widget.arabic ? ar : en;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(t('تحدي Python', 'Python Challenge'))),
      body: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Icon(Icons.workspace_premium, size: 65),
            const SizedBox(height: 16),
            Text(
              t('تحدي اليوم', 'Daily Challenge'),
              style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 12),
            Text(
              t(
                'اكتب كودًا يطبع الأرقام من 1 إلى 5 باستخدام حلقة for.',
                'Write code that prints numbers from 1 to 5 using a for loop.',
              ),
              style: const TextStyle(fontSize: 17, height: 1.6),
            ),
            const SizedBox(height: 18),
            CodeBox(code: 'for i in range(1, 6):\n    print(i)'),
            const Spacer(),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: done
                    ? null
                    : () async {
                        await widget.onPoints(25);
                        setState(() => done = true);
                      },
                icon: const Icon(Icons.check),
                label: Text(
                  done
                      ? t('تم الحصول على 25 نقطة ✓', '25 points earned ✓')
                      : t('حل التحدي', 'Complete challenge'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ProgressPage extends StatelessWidget {
  final bool arabic;
  final int points;
  const ProgressPage({super.key, required this.arabic, required this.points});

  String t(String ar, String en) => arabic ? ar : en;

  @override
  Widget build(BuildContext context) {
    final progress = ((points % 500) / 500).clamp(0.0, 1.0);
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Text(
          t('تقدمي', 'My Progress'),
          style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 16),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                const CircleAvatar(
                  radius: 42,
                  child: Icon(Icons.code, size: 42),
                ),
                const SizedBox(height: 12),
                Text(
                  t('مبتدئ Python', 'Python Beginner'),
                  style: const TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 15),
                LinearProgressIndicator(value: progress),
                const SizedBox(height: 8),
                Text('$points ${t('نقطة', 'points')}'),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: StatCard(value: '7', label: t('دروس', 'Lessons')),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: StatCard(value: '12', label: t('تمارين', 'Exercises')),
            ),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(
              child: StatCard(value: '5', label: t('إنجازات', 'Badges')),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: StatCard(
                value: '3',
                label: t('أيام متتالية', 'Day streak'),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class SettingsPage extends StatelessWidget {
  final bool arabic;
  final ValueChanged<bool> onLanguageChanged;
  final VoidCallback onLogout;

  const SettingsPage({
    super.key,
    required this.arabic,
    required this.onLanguageChanged,
    required this.onLogout,
  });

  String t(String ar, String en) => arabic ? ar : en;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Text(
          t('الإعدادات', 'Settings'),
          style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 18),
        Card(
          child: ListTile(
            leading: const Icon(Icons.language),
            title: Text(t('لغة التطبيق', 'App language')),
            subtitle: Text(arabic ? 'العربية' : 'English'),
            trailing: Switch(value: arabic, onChanged: onLanguageChanged),
          ),
        ),
        Card(
          child: ListTile(
            leading: const Icon(Icons.dns),
            title: Text(
              t(
                'عنوان خادم Python والذكاء الاصطناعي',
                'Python & AI server URL',
              ),
            ),
            subtitle: Text(PythonBackend.baseUrl),
            onTap: () async {
              final c = TextEditingController(text: PythonBackend.baseUrl);
              final value = await showDialog<String>(
                context: context,
                builder: (_) => AlertDialog(
                  title: Text(t('عنوان الخادم', 'Server URL')),
                  content: TextField(
                    controller: c,
                    keyboardType: TextInputType.url,
                    decoration: InputDecoration(
                      hintText: 'https://your-replit-domain/api',
                    ),
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: Text(t('إلغاء', 'Cancel')),
                    ),
                    FilledButton(
                      onPressed: () => Navigator.pop(context, c.text),
                      child: Text(t('حفظ', 'Save')),
                    ),
                  ],
                ),
              );
              if (value != null && value.trim().isNotEmpty) {
                try {
                  await ApiConfig.setBaseUrl(value);
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          t('تم حفظ عنوان الخادم', 'Server URL saved'),
                        ),
                      ),
                    );
                  }
                } on FormatException catch (e) {
                  if (context.mounted) {
                    ScaffoldMessenger.of(
                      context,
                    ).showSnackBar(SnackBar(content: Text(e.message)));
                  }
                }
              }
            },
          ),
        ),
        Card(
          child: ListTile(
            leading: const Icon(Icons.logout),
            title: Text(t('تسجيل الخروج', 'Log out')),
            onTap: onLogout,
          ),
        ),
        Card(
          child: ListTile(
            leading: const Icon(Icons.info_outline),
            title: Text(t('عن التطبيق', 'About')),
            subtitle: Text(
              t(
                'Python — تعلم البرمجة بطريقة عملية.',
                'Python — Learn programming by doing.',
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class PremiumPage extends StatelessWidget {
  final bool arabic;
  final PremiumService service;

  const PremiumPage({super.key, required this.arabic, required this.service});

  String t(String ar, String en) => arabic ? ar : en;

  @override
  Widget build(BuildContext context) {
    final monthly = service.products
        .where((p) => p.id == PremiumService.monthlyId)
        .toList();
    final yearly = service.products
        .where((p) => p.id == PremiumService.yearlyId)
        .toList();

    return Scaffold(
      appBar: AppBar(title: Text(t('Python Premium', 'Python Premium'))),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(28),
              gradient: const LinearGradient(
                colors: [Color(0xFFFFB300), Color(0xFFE65100)],
              ),
            ),
            child: Column(
              children: [
                const Icon(Icons.workspace_premium, size: 72),
                const SizedBox(height: 10),
                Text(
                  t('افتح قوة Python كاملة', 'Unlock the full power of Python'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 25,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  t(
                    'تعلم أسرع، صحح أكوادك، واستخدم المدرس الذكي.',
                    'Learn faster, debug your code and use the AI tutor.',
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          ...[
            t('🤖 مدرس AI موسّع', '🤖 Extended AI Tutor'),
            t('🐛 تصحيح وشرح متقدم للكود', '🐛 Advanced code debugging'),
            t('📷 تحليل صور الكود', '📷 Code image analysis'),
            t('▶️ تشغيل الأكواد', '▶️ Run Python code'),
            t('📚 جميع مسارات التعلم', '📚 All learning paths'),
            t('🚫 بدون إعلانات', '🚫 Ad-free'),
            t('🏆 تحديات ومشاريع متقدمة', '🏆 Advanced challenges & projects'),
          ].map(
            (x) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 7),
              child: Row(
                children: [
                  const Icon(Icons.check_circle, color: Colors.greenAccent),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(x, style: const TextStyle(fontSize: 16)),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          if (service.premium)
            Container(
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                color: Colors.green.withValues(alpha: .12),
                borderRadius: BorderRadius.circular(18),
              ),
              child: Text(
                t('👑 أنت مشترك في Premium', '👑 You have Premium'),
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
            )
          else ...[
            _PlanButton(
              title: t('Premium شهري', 'Monthly Premium'),
              price: monthly.isNotEmpty
                  ? monthly.first.price
                  : t('49 ج.م / شهر', '49 EGP / month'),
              onTap: () async {
                if (monthly.isNotEmpty) {
                  await service.buy(monthly.first);
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(t('الاشتراك الشهري غير متاح حاليًا. أضفه في Google Play Console أولًا.', 'Monthly subscription is not available yet. Add it in Google Play Console first.'))),
                  );
                }
              },
            ),
            const SizedBox(height: 10),
            _PlanButton(
              title: t('Premium سنوي', 'Yearly Premium'),
              price: yearly.isNotEmpty
                  ? yearly.first.price
                  : t('399 ج.م / سنة', '399 EGP / year'),
              highlighted: true,
              onTap: () async {
                if (yearly.isNotEmpty) {
                  await service.buy(yearly.first);
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text(t('الاشتراك السنوي غير متاح حاليًا. أضفه في Google Play Console أولًا.', 'Yearly subscription is not available yet. Add it in Google Play Console first.'))),
                  );
                }
              },
            ),
            const SizedBox(height: 12),
            OutlinedButton(
              onPressed: service.restore,
              child: Text(t('استعادة المشتريات', 'Restore purchases')),
            ),
          ],
        ],
      ),
    );
  }
}

class _PlanButton extends StatelessWidget {
  final String title;
  final String price;
  final bool highlighted;
  final VoidCallback onTap;

  const _PlanButton({
    required this.title,
    required this.price,
    this.highlighted = false,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: highlighted ? Colors.amber : Colors.white.withValues(alpha: .15),
        ),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 5),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text(price),
        trailing: FilledButton(onPressed: onTap, child: const Text('ابدأ')),
      ),
    );
  }
}

class FeatureCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const FeatureCard({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(24),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          color: color.withValues(alpha: .12),
          border: Border.all(color: color.withValues(alpha: .28)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 25,
              backgroundColor: color.withValues(alpha: .22),
              child: Icon(icon, color: color),
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              style: TextStyle(color: Colors.white.withValues(alpha: .68)),
            ),
          ],
        ),
      ),
    );
  }
}

class StatCard extends StatelessWidget {
  final String value;
  final String label;
  const StatCard({super.key, required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 20),
        child: Column(
          children: [
            Text(
              value,
              style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 4),
            Text(label),
          ],
        ),
      ),
    );
  }
}

class CodeBox extends StatelessWidget {
  final String code;
  const CodeBox({super.key, required this.code});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF020916),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.blue.withValues(alpha: .22)),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Text(
          code,
          style: const TextStyle(
            fontFamily: 'monospace',
            fontSize: 14,
            height: 1.6,
          ),
        ),
      ),
    );
  }
}

class PythonLogo extends StatelessWidget {
  final double size;
  const PythonLogo({super.key, required this.size});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(size * .25),
        gradient: const LinearGradient(
          colors: [Color(0xFF3776AB), Color(0xFFFFD343)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: Icon(Icons.code, size: size * .62, color: Colors.white),
    );
  }
}
