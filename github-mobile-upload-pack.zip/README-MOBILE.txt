# Python Tutor — Mobile GitHub Upload

هذا الباك مخصص للرفع من الهاتف.

## المطلوب على GitHub

1. ارفع `python-tutor-project.zip` إلى جذر الـRepository.
2. أنشئ الملف:
   `.github/workflows/build-apk.yml`
3. انسخ محتوى `build-apk.yml` الموجود هنا داخله.
4. من تبويب Actions شغّل **Build Android APK**.
5. بعد انتهاء البناء افتح الـworkflow ثم **Artifacts** وحمّل `python-tutor-release-apk`.

ملاحظة: المشروع لا يحتوي على API keys أو كلمات مرور. لا تضع الأسرار داخل GitHub.
