import 'package:shared_preferences/shared_preferences.dart';

class ApiConfig {
  static const _savedUrlKey = 'api_base_url';
  static const _defaultUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'https://python-tutor-backend--yunes7991.replit.app/api',
  );

  static String baseUrl = _normalize(_defaultUrl);

  static Future<void> load() async {
    final preferences = await SharedPreferences.getInstance();
    final saved = preferences.getString(_savedUrlKey);
    if (saved != null && saved.trim().isNotEmpty) {
      baseUrl = _normalize(saved);
    }
  }

  static Future<void> setBaseUrl(String value) async {
    final normalized = _normalize(value);
    if (normalized.isEmpty) {
      throw const FormatException('Enter a valid server URL.');
    }
    final uri = Uri.tryParse(normalized);
    if (uri == null || !uri.hasScheme || uri.host.isEmpty) {
      throw const FormatException('Enter a valid http(s) server URL.');
    }
    if (uri.scheme != 'http' && uri.scheme != 'https') {
      throw const FormatException('The server URL must use http or https.');
    }
    baseUrl = normalized;
    final preferences = await SharedPreferences.getInstance();
    await preferences.setString(_savedUrlKey, normalized);
  }

  static String _normalize(String value) {
    return value.trim().replaceFirst(RegExp(r'/+$'), '');
  }
}
