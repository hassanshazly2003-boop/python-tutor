import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:in_app_purchase/in_app_purchase.dart';

class PremiumService extends ChangeNotifier {
  static const monthlyId = 'python_premium_monthly';
  static const yearlyId = 'python_premium_yearly';

  final InAppPurchase _iap = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _subscription;

  bool premium = false;
  bool storeAvailable = false;
  List<ProductDetails> products = [];
  bool loading = true;

  PremiumService() {
    _subscription = _iap.purchaseStream.listen(
      _onPurchases,
      onDone: () => _subscription?.cancel(),
    );
    initialize();
  }

  Future<void> initialize() async {
    loading = true;
    notifyListeners();
    storeAvailable = await _iap.isAvailable();
    if (storeAvailable) {
      final response = await _iap.queryProductDetails({monthlyId, yearlyId});
      products = response.productDetails;
    }
    loading = false;
    notifyListeners();
  }

  Future<void> buy(ProductDetails product) async {
    await _iap.buyNonConsumable(
      purchaseParam: PurchaseParam(productDetails: product),
    );
  }

  Future<void> restore() async {
    if (storeAvailable) await _iap.restorePurchases();
  }

  Future<void> _onPurchases(List<PurchaseDetails> purchases) async {
    for (final purchase in purchases) {
      if ((purchase.productID == monthlyId || purchase.productID == yearlyId) &&
          (purchase.status == PurchaseStatus.purchased ||
              purchase.status == PurchaseStatus.restored)) {
        premium = true;
        notifyListeners();
      }
      if (purchase.pendingCompletePurchase) {
        await _iap.completePurchase(purchase);
      }
    }
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }
}
