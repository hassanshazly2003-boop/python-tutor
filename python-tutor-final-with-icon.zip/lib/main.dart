import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  runApp(PythonTutorApp(prefs: prefs));
}

class C {
  static const bg = Color(0xFF0A1931);
  static const panel = Color(0xFF0C2342);
  static const panel2 = Color(0xFF102D51);
  static const blue = Color(0xFF1188FF);
  static const cyan = Color(0xFF20B7FF);
  static const green = Color(0xFF18D58A);
  static const purple = Color(0xFF7546F4);
  static const orange = Color(0xFFFF9B27);
  static const pink = Color(0xFFD946EF);
  static const red = Color(0xFFFF4F62);
  static const yellow = Color(0xFFFFD43B);
  static const muted = Color(0xFF8EA3BD);
}

class PythonTutorApp extends StatelessWidget {
  final SharedPreferences prefs;
  const PythonTutorApp({super.key, required this.prefs});

  @override
  Widget build(BuildContext context) {
    final done = prefs.getBool('onboarding_done') ?? false;
    final lang = prefs.getString('language') ?? 'ar';
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Python Tutor',
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: C.bg,
        colorScheme: const ColorScheme.dark(primary: C.blue, secondary: C.cyan),
        textTheme: GoogleFonts.cairoTextTheme(ThemeData.dark().textTheme),
        appBarTheme: const AppBarTheme(backgroundColor: Colors.transparent, elevation: 0, surfaceTintColor: Colors.transparent),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: const Color(0xFF0B203A),
          hintStyle: const TextStyle(color: Colors.white38),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Color(0x334A94D1))),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Color(0x334A94D1))),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: C.blue)),
        ),
        navigationBarTheme: NavigationBarThemeData(
          backgroundColor: const Color(0xFF07172B),
          indicatorColor: const Color(0xFF163D68),
          labelTextStyle: WidgetStateProperty.all(const TextStyle(fontSize: 10, fontWeight: FontWeight.w700)),
        ),
      ),
      home: done ? HomeShell(language: lang, prefs: prefs) : Splash(prefs: prefs),
    );
  }
}

class CardBox extends StatelessWidget {
  final Widget child;
  final List<Color> colors;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  const CardBox({super.key, required this.child, this.colors = const [Color(0xFF124C91), Color(0xFF0C294E)], this.padding = const EdgeInsets.all(16), this.onTap});
  @override
  Widget build(BuildContext context) {
    final box = Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: colors),
        border: Border.all(color: const Color(0x334A9DDD)),
        boxShadow: const [BoxShadow(color: Color(0x30000000), blurRadius: 16, offset: Offset(0, 8))],
      ),
      padding: padding,
      child: child,
    );
    if (onTap == null) return box;
    return Material(color: Colors.transparent, child: InkWell(borderRadius: BorderRadius.circular(20), onTap: onTap, child: box));
  }
}

class Btn extends StatelessWidget {
  final String text;
  final VoidCallback? onTap;
  final IconData? icon;
  final Color color;
  const Btn({super.key, required this.text, required this.onTap, this.icon, this.color = C.blue});
  @override
  Widget build(BuildContext context) => SizedBox(
    width: double.infinity,
    height: 53,
    child: ElevatedButton.icon(
      onPressed: onTap,
      icon: icon == null ? const SizedBox.shrink() : Icon(icon),
      label: Text(text, style: const TextStyle(fontWeight: FontWeight.w900)),
      style: ElevatedButton.styleFrom(backgroundColor: color, foregroundColor: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(17))),
    ),
  );
}

class PythonLogo extends StatelessWidget {
  final double size;
  const PythonLogo({super.key, this.size = 100});

  @override
  Widget build(BuildContext context) => SizedBox(
    width: size,
    height: size,
    child: Image.asset(
      'assets/app_icon.png',
      width: size,
      height: size,
      fit: BoxFit.contain,
      filterQuality: FilterQuality.high,
    ),
  );
}

class Bot extends StatelessWidget {
  final double size;
  const Bot({super.key, this.size = 48});
  @override
  Widget build(BuildContext context) => Container(width: size, height: size, decoration: const BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: [Color(0xFF159DFF), Color(0xFF5942E6)])), child: Icon(Icons.smart_toy_rounded, size: size*.56));
}

class Splash extends StatefulWidget {
  final SharedPreferences prefs;
  const Splash({super.key, required this.prefs});
  @override State<Splash> createState() => _SplashState();
}
class _SplashState extends State<Splash> with SingleTickerProviderStateMixin {
  late final AnimationController c;
  @override void initState() { super.initState(); c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1900))..forward(); Future.delayed(const Duration(milliseconds: 2200), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => LanguagePage(prefs: widget.prefs)));
    }); }
  @override void dispose() { c.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) => Scaffold(body: Container(decoration: const BoxDecoration(gradient: RadialGradient(center: Alignment(0,-.2), radius: 1.1, colors: [Color(0xFF0D3D75), C.bg])), child: SafeArea(child: Center(child: AnimatedBuilder(animation: c, builder: (_,__) => Column(mainAxisAlignment: MainAxisAlignment.center, children: [Transform.scale(scale: .85+c.value*.15, child: const PythonLogo(size: 142)), const SizedBox(height: 22), const Text('Python', style: TextStyle(fontSize: 42, fontWeight: FontWeight.w900)), const SizedBox(height: 7), const Text('تعلم  •  اكتب  •  شغل  •  صحح  •  طور', style: TextStyle(fontSize: 15, color: Colors.white70, fontWeight: FontWeight.w700)), const SizedBox(height: 58), SizedBox(width: 165, child: ClipRRect(borderRadius: BorderRadius.circular(20), child: LinearProgressIndicator(value: c.value, minHeight: 5, backgroundColor: Colors.white12, valueColor: const AlwaysStoppedAnimation(C.blue)))), const SizedBox(height: 9), const Text('جاري التحميل ...', style: TextStyle(color: Colors.white45, fontSize: 11))]))))));
}

class LanguagePage extends StatefulWidget {
  final SharedPreferences prefs;
  const LanguagePage({super.key, required this.prefs});
  @override State<LanguagePage> createState() => _LanguagePageState();
}
class _LanguagePageState extends State<LanguagePage> {
  String lang = 'ar';
  Future<void> go() async { await widget.prefs.setBool('onboarding_done', true); await widget.prefs.setString('language', lang); if (!mounted) return; Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => HomeShell(language: lang, prefs: widget.prefs))); }
  @override Widget build(BuildContext context) => Scaffold(body: SafeArea(child: Padding(padding: const EdgeInsets.fromLTRB(24,55,24,24), child: Column(children: [const PythonLogo(size: 105), const SizedBox(height:20), const Text('اختر لغة التطبيق', style: TextStyle(fontSize:26,fontWeight:FontWeight.w900)), const SizedBox(height:3), const Text('Choose your language', style: TextStyle(color:Colors.white54)), const SizedBox(height:30), LangCard(flag:'🇪🇬', title:'العربية', sub:'Arabic', selected:lang=='ar', tap:()=>setState(()=>lang='ar')), const SizedBox(height:13), LangCard(flag:'🇬🇧', title:'English', sub:'English', selected:lang=='en', tap:()=>setState(()=>lang='en')), const Spacer(), Btn(text:lang=='ar'?'متابعة':'Continue', icon:Icons.arrow_forward_rounded, onTap:go)]))));
}
class LangCard extends StatelessWidget { final String flag,title,sub; final bool selected; final VoidCallback tap; const LangCard({super.key,required this.flag,required this.title,required this.sub,required this.selected,required this.tap}); @override Widget build(BuildContext context)=>Material(color:Colors.transparent,child:InkWell(borderRadius:BorderRadius.circular(19),onTap:tap,child:AnimatedContainer(duration:const Duration(milliseconds:180),padding:const EdgeInsets.all(16),decoration:BoxDecoration(borderRadius:BorderRadius.circular(19),gradient:LinearGradient(colors:selected?[const Color(0xFF168FFF),const Color(0xFF0759C8)]:[const Color(0xFF102947),const Color(0xFF0B203B)]),border:Border.all(color:selected?const Color(0xFF4EB9FF):const Color(0x224A9BDD))),child:Row(children:[Text(flag,style:const TextStyle(fontSize:35)),const SizedBox(width:14),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:17,fontWeight:FontWeight.w900)),Text(sub,style:const TextStyle(color:Colors.white70,fontSize:12))])),if(selected)const Icon(Icons.check_circle_rounded)])))); }

class HomeShell extends StatefulWidget {
  final String language; final SharedPreferences prefs;
  const HomeShell({super.key, required this.language, required this.prefs});
  @override State<HomeShell> createState()=>_HomeShellState();
}
class _HomeShellState extends State<HomeShell> {
  int index=0;
  @override Widget build(BuildContext context){ final ar=widget.language=='ar'; final pages=[HomePage(ar:ar),LessonsPage(ar:ar),ProgressPage(ar:ar),SettingsPage(ar:ar)]; return Directionality(textDirection:ar?TextDirection.rtl:TextDirection.ltr,child:Scaffold(body:IndexedStack(index:index,children:pages),bottomNavigationBar:NavigationBar(selectedIndex:index,onDestinationSelected:(v)=>setState(()=>index=v),destinations:[NavigationDestination(icon:const Icon(Icons.home_outlined),selectedIcon:const Icon(Icons.home_rounded,color:C.cyan),label:ar?'الرئيسية':'Home'),NavigationDestination(icon:const Icon(Icons.menu_book_outlined),selectedIcon:const Icon(Icons.menu_book_rounded,color:C.cyan),label:ar?'الدروس':'Lessons'),NavigationDestination(icon:const Icon(Icons.insights_outlined),selectedIcon:const Icon(Icons.insights_rounded,color:C.cyan),label:ar?'سجل التقدم':'Progress'),NavigationDestination(icon:const Icon(Icons.settings_outlined),selectedIcon:const Icon(Icons.settings_rounded,color:C.cyan),label:ar?'الإعدادات':'Settings')]))); }
}

class HomePage extends StatelessWidget {
  final bool ar; const HomePage({super.key,required this.ar});
  @override Widget build(BuildContext context)=>SafeArea(child:CustomScrollView(slivers:[SliverPadding(padding:const EdgeInsets.fromLTRB(18,10,18,0),sliver:SliverToBoxAdapter(child:Row(children:[const Bot(size:47),const SizedBox(width:11),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('مرحبا بك 👋',style:TextStyle(color:Colors.white70,fontSize:12)),Text('مطور المستقبل',style:TextStyle(fontSize:17,fontWeight:FontWeight.w900))])),const Icon(Icons.workspace_premium_rounded,color:C.yellow)]))),SliverPadding(padding:const EdgeInsets.fromLTRB(18,17,18,11),sliver:SliverToBoxAdapter(child:CardBox(colors:const [Color(0xFF168EFF),Color(0xFF0758C7)],padding:const EdgeInsets.all(15),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>LessonsPage(ar:ar))),child:Row(children:[Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(ar?'ابدأ رحلتك في تعلم بايثون':'Start your Python journey',style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:4),Text(ar?'من الصفر حتى الاحتراف  →':'From zero to professional  →',style:const TextStyle(color:Colors.white70,fontSize:11))])),const PythonLogo(size:70)])))),SliverPadding(padding:const EdgeInsets.symmetric(horizontal:18),sliver:SliverGrid(delegate:SliverChildListDelegate([Feature('تعلم Python',Icons.menu_book_rounded,[C.purple,const Color(0xFF4B2EB4)],()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>LessonsPage(ar:ar)))),Feature('صور الكود',Icons.photo_camera_rounded,[C.green,const Color(0xFF0E9A68)],()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const CameraPage()))),Feature('محرر الأكواد',Icons.code_rounded,[const Color(0xFF0EA8F7),const Color(0xFF096BCF)],()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const EditorPage()))),Feature('اكتشف الأخطاء',Icons.bug_report_rounded,[C.orange,const Color(0xFFE96B0B)],()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const CameraPage()))),Feature('اسأل المدرس',Icons.smart_toy_rounded,[C.pink,const Color(0xFF9838BA)],()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const TeacherPage()))),Feature('تقدمي',Icons.emoji_events_rounded,[const Color(0xFF16C8AF),const Color(0xFF078D82)],()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ProgressPage(ar:ar)))]),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,crossAxisSpacing:11,mainAxisSpacing:11,childAspectRatio:1.15))),const SliverToBoxAdapter(child:SizedBox(height:20))]));
}
class Feature extends StatelessWidget { final String title; final IconData icon; final List<Color> colors; final VoidCallback tap; const Feature(this.title,this.icon,this.colors,this.tap,{super.key}); @override Widget build(BuildContext context)=>CardBox(colors:colors,padding:const EdgeInsets.all(12),onTap:tap,child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Icon(icon,size:35),const SizedBox(height:10),Text(title,textAlign:TextAlign.center,style:const TextStyle(fontSize:13,fontWeight:FontWeight.w900))])); }

final List<Lesson> lessonData = [
  Lesson('01','يعني إيه Python؟','What is Python?','لغة سهلة بتخلّيك تقول للكمبيوتر يعمل إيه','A simple language for telling computers what to do',Icons.code_rounded),
  Lesson('02','المتغيرات (العلب)','Variables (Boxes)','خزّن قيمة واستخدمها وقت ما تحتاج','Store a value and reuse it',Icons.inventory_2_rounded),
  Lesson('03','أنواع البيانات','Data Types','كل قيمة ليها نوع مناسب','Every value has a type',Icons.data_object_rounded),
  Lesson('04','جملة if (لو حصل كذا)','if Statement','خلّي البرنامج ياخد قرار','Let your program make a decision',Icons.alt_route_rounded),
  Lesson('05','حلقة for','for Loop','كرّر نفس الأمر من غير ما تكتبه كل مرة','Repeat an action without writing it again',Icons.loop_rounded),
  Lesson('06','الدوال Functions','Functions','اجمع أوامر مع بعض واستدعيها وقت ما تحتاج','Group instructions and reuse them',Icons.functions_rounded),
];

class Lesson { final String no,ar,en,arSub,enSub; final IconData icon; const Lesson(this.no,this.ar,this.en,this.arSub,this.enSub,this.icon); }

String lessonMd(int i,bool ar){
  final arText=<String>[
'''# يعني إيه Python؟ 🐍

### 🧩 تخيلها كده

تخيل إنك بتكلم شخص أجنبي ومش فاهم عربي. هتحتاج **مترجم** يحوّل كلامك لحاجة الشخص التاني يفهمها.

Python شبه المترجم ده: بتكتب أوامر بطريقة سهلة، والكمبيوتر ينفذها.

### ليه بنستخدم Python؟

عشان Python سهلة القراءة والكتابة، وممكن تستخدمها في المواقع والذكاء الاصطناعي وتحليل البيانات والأتمتة والألعاب.

### مثال صغير جداً

```python
print("أهلاً يا بطل!")
```

الأمر ده بيقول للكمبيوتر يطبع الجملة على الشاشة.

### 💡 خد بالك

أشهر غلطة في البداية إنك تنسى الأقواس `()` بعد `print`.

غلط:

```python
print "Hello"
```

صح:

```python
print("Hello")
```

### 🎯 تحدي

غيّر الجملة وخلي البرنامج يطبع اسمك.
''',
'''# المتغيرات 📦

### 🧩 تخيلها كده

تخيل عندك **علبة** وكتبت عليها "الاسم". بتحط جواها اسم شخص، ولما تحتاج الاسم تستخدم العلبة دي.

المتغير في Python نفس الفكرة: اسم بنحطه على قيمة عشان نرجع لها بعدين.

### ليه بنستخدمها؟

بدل ما تكتب نفس المعلومة كل مرة، خزّنها مرة واحدة واستخدم اسم المتغير.

### مثال صغير جداً

```python
name = "محمد"
print(name)
```

هنا عملنا علبة اسمها `name` وحطينا جواها "محمد".

### 💡 خد بالك

علامة `=` هنا معناها **خزّن القيمة في المتغير**، مش مقارنة رياضية.

```python
age = 15
```

### 🎯 تحدي

اعمل متغير اسمه `city` وخزّن فيه اسم مدينتك، وبعدها اطبعه.
''',
'''# أنواع البيانات 🔢

### 🧩 تخيلها كده

زي ما عندك كتاب وزجاجة وفلوس وصورة، كل حاجة ليها **نوع** وطريقة استخدام مختلفة.

في Python القيم كمان ليها أنواع.

### ليه بنستخدمها؟

عشان الكمبيوتر يعرف يتعامل مع القيمة بالشكل الصح.

- `str` للنصوص.
- `int` للأرقام الصحيحة.
- `float` للأرقام العشرية.
- `bool` لـ `True` أو `False`.

### مثال صغير جداً

```python
name = "Ali"
age = 15
height = 1.7
student = True

print(age)
```

### 💡 خد بالك

متخلطش بين الرقم والنص:

```python
age = 15
```

ده رقم، لكن:

```python
age = "15"
```

ده نص حتى لو شكله رقم.

### 🎯 تحدي

اعمل `name` و`age` و`height` و`student` وكل واحد يكون بنوع مناسب.
''',
'''# جملة if 🔀

### 🧩 تخيلها كده

تخيل إنك بتقول: **لو الجو مطر، خد الشمسيّة.**

ده بالضبط اللي `if` بتعمله: تختبر شرط، ولو الشرط صح تنفذ أمر.

### ليه بنستخدمها؟

عشان البرنامج ياخد قرارات بدل ما يعمل نفس الحاجة في كل الحالات.

### مثال صغير جداً

```python
age = 15

if age >= 15:
    print("مسموح")
```

### 💡 خد بالك

متنساش النقطتين `:` والمسافة البادئة للكود اللي جوه `if`.

```python
if age >= 15:
    print("مسموح")
```

### 🎯 تحدي

غيّر `age` وخلي البرنامج يطبع رسالة مختلفة لو السن أقل من 15.
''',
'''# حلقة for 🔁

### 🧩 تخيلها كده

تخيل المدرس قالك: **اكتب كلمة Python خمس مرات.** بدل ما تكتبها بإيدك خمس مرات، خلّي الكمبيوتر يكررها.

### ليه بنستخدمها؟

لما يكون عندك نفس العملية وعايز تكررها عدد معين من المرات.

### مثال صغير جداً

```python
for i in range(5):
    print(i)
```

البرنامج هيطبع من 0 لحد 4.

### 💡 خد بالك

`range(5)` تبدأ من 0 ومش بتوصل للرقم 5.

### 🎯 تحدي

خلّي البرنامج يطبع اسمك 5 مرات بدل الأرقام.
''',
'''# الدوال Functions 🧩

### 🧩 تخيلها كده

تخيل **زرار في الريموت**. كل ما تدوس عليه بيعمل مجموعة خطوات جاهزة.

الدالة نفس الفكرة: بتحط شوية أوامر مع بعض، وبعد كده تنادي الدالة وقت ما تحتاجها.

### ليه بنستخدمها؟

عشان منكررش نفس الكود، ونخلي البرنامج منظم وأسهل في التعديل.

### مثال صغير جداً

```python
def hello():
    print("أهلاً يا بطل")

hello()
```

### 💡 خد بالك

متنساش `:` بعد اسم الدالة، وخلي الكود اللي جواها بمسافة بادئة.

### 🎯 تحدي

اعمل دالة اسمها `welcome` تطبع اسمك، وبعد كده شغّلها مرتين.
'''];
  final enText=<String>[
'''# What is Python? 🐍

### 🧩 Think of it this way

Imagine talking to someone who speaks another language. You need a **translator** to turn your words into something they understand.

Python is similar: you write simple instructions and the computer follows them.

### Why do we use Python?

It is easy to read and write, and it is used for websites, AI, data, automation, and games.

### Tiny example

```python
print("Hello, Python!")
```

### 💡 Watch out

A common beginner mistake is forgetting `()` after `print`.

Correct:

```python
print("Hello")
```

### 🎯 Challenge

Change the message and make Python print your own name.
''',
'''# Variables 📦

### 🧩 Think of them as boxes

Imagine a **box** labeled `name`. You put a value inside it and use the label whenever you need that value.

### Why do we use them?

Variables let us store information once and reuse it.

### Tiny example

```python
name = "Ahmed"
print(name)
```

### 💡 Watch out

`=` means **store/assign a value** in this context.

```python
age = 15
```

### 🎯 Challenge

Create a `city` variable, store your city, then print it.
''',
'''# Data Types 🔢

### 🧩 Think of different kinds of things

A book, a bottle, money, and a photo are different kinds of things. Python values also have different types.

### Why do we use them?

The type tells Python how a value should be handled.

- `str` = text
- `int` = whole number
- `float` = decimal number
- `bool` = `True` or `False`

### Tiny example

```python
name = "Ali"
age = 15
height = 1.7
student = True

print(age)
```

### 💡 Watch out

Do not confuse a number with text.

```python
age = 15
```

is a number, while:

```python
age = "15"
```

is text.

### 🎯 Challenge

Create `name`, `age`, `height`, and `student` using the correct types.
''',
'''# if Statement 🔀

### 🧩 Think of it this way

Imagine saying: **If it is raining, take an umbrella.**

That is what `if` does: it checks a condition and runs code when it is true.

### Why do we use it?

So the program can make decisions.

### Tiny example

```python
age = 15

if age >= 15:
    print("Allowed")
```

### 💡 Watch out

Do not forget the `:` and the indentation.

```python
if age >= 15:
    print("Allowed")
```

### 🎯 Challenge

Change `age` and make the program print a different message when the age is below 15.
''',
'''# for Loop 🔁

### 🧩 Think of it this way

Imagine your teacher asks you to write Python five times. Instead of doing it manually, ask the computer to repeat the action.

### Why do we use it?

Use a loop when you need to repeat the same action several times.

### Tiny example

```python
for i in range(5):
    print(i)
```

It prints 0 through 4.

### 💡 Watch out

`range(5)` starts at 0 and stops before 5.

### 🎯 Challenge

Make the program print your name five times instead of the numbers.
''',
'''# Functions 🧩

### 🧩 Think of a function like a button

Imagine a **remote-control button**. Every time you press it, a ready-made set of actions happens.

### Why do we use functions?

They help us reuse code and keep programs organized.

### Tiny example

```python
def hello():
    print("Hello!")

hello()
```

### 💡 Watch out

Do not forget the `:` and the indentation inside the function.

### 🎯 Challenge

Create a function called `welcome` that prints your name, then call it twice.
'''];
  return ar ? arText[i] : enText[i];
}

class LessonsPage extends StatelessWidget {
  final bool ar; const LessonsPage({super.key,required this.ar});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(ar?'دروس بايثون':'Python Lessons',style:const TextStyle(fontWeight:FontWeight.w900)),actions:[const Icon(Icons.search_rounded),const SizedBox(width:16)]),body:ListView(padding:const EdgeInsets.fromLTRB(17,2,17,28),children:[Row(children:[Expanded(child:CardBox(colors:const [Color(0xFF147EEC),Color(0xFF0755BD)],padding:const EdgeInsets.symmetric(vertical:12),child:Text(ar?'المستوى الأول':'Level 1',textAlign:TextAlign.center,style:const TextStyle(fontWeight:FontWeight.w900)))),const SizedBox(width:9),Expanded(child:CardBox(colors:const [Color(0xFF102947),Color(0xFF0C203A)],padding:const EdgeInsets.symmetric(vertical:12),child:Text(ar?'المستوى الثاني':'Level 2',textAlign:TextAlign.center,style:const TextStyle(color:Colors.white54,fontWeight:FontWeight.w900))))]),const SizedBox(height:13),ProgressBar(title:ar?'التقدم في المستوى الأول':'Level 1 progress',value:.5),const SizedBox(height:12),...List.generate(lessonData.length,(i)=>LessonTile(data:lessonData[i],ar:ar,index:i)),const SizedBox(height:10),ProgressBar(title:ar?'المستوى الثاني':'Level 2',value:.08),const SizedBox(height:10),LockedTile(number:'01',title:ar?'القوائم والقواميس':'Lists & Dictionaries',sub:ar?'أكمل المستوى الأول أولاً':'Complete Level 1 first'),LockedTile(number:'02',title:ar?'المشاريع الصغيرة':'Mini Projects',sub:ar?'أكمل المستوى الأول أولاً':'Complete Level 1 first')]));
}
class ProgressBar extends StatelessWidget { final String title; final double value; const ProgressBar({super.key,required this.title,required this.value}); @override Widget build(BuildContext context)=>CardBox(colors:const [Color(0xFF102F57),Color(0xFF0C213D)],padding:const EdgeInsets.symmetric(horizontal:14,vertical:12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:13,fontWeight:FontWeight.w900)),const SizedBox(height:8),ClipRRect(borderRadius:BorderRadius.circular(20),child:LinearProgressIndicator(value:value,minHeight:7,backgroundColor:Colors.white10,valueColor:const AlwaysStoppedAnimation(C.cyan)))])); }
class LessonTile extends StatelessWidget { final Lesson data; final bool ar; final int index; const LessonTile({super.key,required this.data,required this.ar,required this.index}); @override Widget build(BuildContext context)=>Container(margin:const EdgeInsets.only(bottom:9),decoration:BoxDecoration(color:const Color(0xFF0C2443),borderRadius:BorderRadius.circular(17),border:Border.all(color:const Color(0x254D9DDA))),child:ListTile(onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>LessonDetail(data:data,ar:ar,index:index))),contentPadding:const EdgeInsets.symmetric(horizontal:11,vertical:4),leading:Container(width:45,height:45,decoration:BoxDecoration(borderRadius:BorderRadius.circular(14),gradient:const LinearGradient(colors:[Color(0xFF1395F5),Color(0xFF0758C4)])),child:Center(child:Text(data.no,style:const TextStyle(fontWeight:FontWeight.w900)))),title:Text(ar?data.ar:data.en,style:const TextStyle(fontSize:14,fontWeight:FontWeight.w900)),subtitle:Text(ar?data.arSub:data.enSub,style:const TextStyle(color:Colors.white54,fontSize:10)),trailing:const Icon(Icons.chevron_left_rounded,color:C.cyan))); }
class LockedTile extends StatelessWidget { final String number,title,sub; const LockedTile({super.key,required this.number,required this.title,required this.sub}); @override Widget build(BuildContext context)=>Container(margin:const EdgeInsets.only(bottom:9),decoration:BoxDecoration(color:const Color(0xFF0A1E37),borderRadius:BorderRadius.circular(17),border:Border.all(color:const Color(0x1C4B8FC7))),child:ListTile(contentPadding:const EdgeInsets.symmetric(horizontal:11,vertical:4),leading:Container(width:45,height:45,decoration:BoxDecoration(color:Colors.white10,borderRadius:BorderRadius.circular(14)),child:Center(child:Text(number,style:const TextStyle(color:Colors.white54,fontWeight:FontWeight.w900)))),title:Text(title,style:const TextStyle(color:Colors.white60,fontWeight:FontWeight.w800)),subtitle:Text(sub,style:const TextStyle(color:Colors.white30,fontSize:10)),trailing:const Icon(Icons.lock_rounded,color:Colors.white24))); }

class LessonDetail extends StatelessWidget {
  final Lesson data; final bool ar; final int index;
  const LessonDetail({super.key,required this.data,required this.ar,required this.index});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(ar?data.ar:data.en,style:const TextStyle(fontWeight:FontWeight.w900)),actions:[Padding(padding:const EdgeInsetsDirectional.only(end:15),child:Center(child:Text(data.no,style:const TextStyle(color:C.cyan,fontWeight:FontWeight.w900))))]),body:ListView(padding:const EdgeInsets.fromLTRB(17,2,17,28),children:[CardBox(colors:const [Color(0xFF124C91),Color(0xFF0B294F)],child:Row(children:[Container(width:45,height:45,decoration:BoxDecoration(color:C.blue.withOpacity(.25),borderRadius:BorderRadius.circular(14)),child:Icon(data.icon,color:C.cyan)),const SizedBox(width:12),Expanded(child:Text(ar?'درس ${data.no} • خطوة جديدة في رحلتك':'Lesson ${data.no} • another step forward',style:const TextStyle(fontWeight:FontWeight.w800)))])),const SizedBox(height:12),MarkdownBody(data:lessonMd(index,ar),selectable:true,styleSheet:MarkdownStyleSheet(h1:const TextStyle(fontSize:24,fontWeight:FontWeight.w900,color:Colors.white),h2:const TextStyle(fontSize:18,fontWeight:FontWeight.w900,color:Colors.white),h3:const TextStyle(fontSize:15,fontWeight:FontWeight.w900,color:C.cyan),p:const TextStyle(fontSize:14,height:1.85,color:Colors.white70),code:const TextStyle(fontFamily:'monospace',fontSize:12,color:Color(0xFF8DE6FF)),codeblockPadding:const EdgeInsets.all(15),codeblockDecoration:BoxDecoration(color:const Color(0xFF051225),borderRadius:BorderRadius.all(Radius.circular(15)),border:Border.fromBorderSide(BorderSide(color:Color(0x2E3E8ED3)))),blockquoteDecoration:BoxDecoration(color:const Color(0xFF102B4C),borderRadius:BorderRadius.all(Radius.circular(13))))),const SizedBox(height:10),Btn(text:ar?'جرّب الكود':'Try the code',icon:Icons.play_arrow_rounded,onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const EditorPage())))]));
}

class EditorPage extends StatefulWidget { const EditorPage({super.key}); @override State<EditorPage> createState()=>_EditorPageState(); }
class _EditorPageState extends State<EditorPage> {
  final code=TextEditingController(text:'name = input("ما اسمك؟")\nif name:\n    print("أهلاً", name)\nelse:\n    print("لم يتم إدخال اسم")');
  final input=TextEditingController(text:'محمد'); String output='ما اسمك؟\nأهلاً محمد';
  @override void dispose(){code.dispose();input.dispose();super.dispose();}
  void run(){ final n=input.text.trim(); setState(()=>output=n.isEmpty?'ما اسمك؟\nلم يتم إدخال اسم':'ما اسمك؟\nأهلاً $n'); }
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('محرر الأكواد',style:TextStyle(fontWeight:FontWeight.w900)),actions:[Container(padding:const EdgeInsets.symmetric(horizontal:11,vertical:8),decoration:BoxDecoration(color:const Color(0xFF102947),borderRadius:BorderRadius.circular(12)),child:const Text('Python',style:TextStyle(fontSize:11))),const SizedBox(width:10)]),body:ListView(padding:const EdgeInsets.fromLTRB(14,2,14,24),children:[CardBox(colors:const [Color(0xFF061326),Color(0xFF041020)],padding:EdgeInsets.zero,child:SizedBox(height:300,child:TextField(controller:code,expands:true,maxLines:null,textAlignVertical:TextAlignVertical.top,style:const TextStyle(fontFamily:'monospace',fontSize:12.5,height:1.55),decoration:const InputDecoration(border:InputBorder.none,contentPadding:EdgeInsets.all(15)))),const SizedBox(height:11),Btn(text:'تشغيل',icon:Icons.play_arrow_rounded,color:C.green,onTap:run),const SizedBox(height:17),const Text('الإدخال',style:TextStyle(fontWeight:FontWeight.w900)),const SizedBox(height:7),TextField(controller:input,decoration:const InputDecoration(prefixIcon:Icon(Icons.keyboard_rounded),hintText:'قيمة input')),const SizedBox(height:17),CardBox(colors:const [Color(0xFF0C294B),Color(0xFF08192F)],child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Row(children:[Icon(Icons.terminal_rounded,color:C.cyan),SizedBox(width:8),Text('النتيجة',style:TextStyle(fontWeight:FontWeight.w900))]),const SizedBox(height:12),SelectableText(output,style:const TextStyle(fontFamily:'monospace',color:Color(0xFF77E5B4),height:1.6))]))]));
}

class CameraPage extends StatefulWidget { const CameraPage({super.key}); @override State<CameraPage> createState()=>_CameraPageState(); }
class _CameraPageState extends State<CameraPage>{ bool loading=false; String result=''; Future<void> analyze() async { setState(() => loading = true); await Future.delayed(const Duration(milliseconds: 700)); if (!mounted) return; setState(() { loading = false; result = 'تم تحليل الكود بنجاح ✅\n\n• مفيش SyntaxError واضح.\n• الكود قابل للتشغيل.\n• جرّب تحسين أسماء المتغيرات.'; }); } @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('صوّر الكود',style:TextStyle(fontWeight:FontWeight.w900)),actions:[const Icon(Icons.flash_on_rounded),const SizedBox(width:17)]),body:Padding(padding:const EdgeInsets.all(17),child:Column(children:[Expanded(child:CardBox(colors:const [Color(0xFF081A30),Color(0xFF051225)],child:Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[Container(width:205,height:265,decoration:BoxDecoration(borderRadius:BorderRadius.circular(20),border:Border.all(color:C.cyan,width:2)),child:const Center(child:Icon(Icons.code_rounded,size:75,color:Colors.white12))),const SizedBox(height:18),const Text('وجّه الكاميرا نحو الكود',style:TextStyle(color:Colors.white60,fontWeight:FontWeight.w700))]))),const SizedBox(height:13),Btn(text:loading?'جاري التحليل...':'تحليل الكود',icon:Icons.camera_alt_rounded,onTap:loading?null:analyze),if(result.isNotEmpty) ...[const SizedBox(height:12),CardBox(child:Text(result,style:const TextStyle(color:Colors.white70,height:1.7)))] ])); }

class TeacherPage extends StatefulWidget { const TeacherPage({super.key}); @override State<TeacherPage> createState()=>_TeacherPageState(); }
class _TeacherPageState extends State<TeacherPage>{ final input=TextEditingController(); final List<Map<String,String>> msgs=[{'b':'1','t':'أهلاً! أنا مدرسك الذكي 🤖\nاسألني عن أي حاجة في Python.'},{'b':'0','t':'اشرح لي حلقة for'},{'b':'1','m':'حلقة `for` بتستخدم لتكرار تنفيذ مجموعة أوامر.\n\n```python\nfor i in range(5):\n    print(i)\n```\n\nفي المثال ده بنطبع من 0 لحد 4.\n\n💡 **خد بالك:** الرقم 5 نفسه مش بيتطبع.'}]; void send(){final x=input.text.trim();if(x.isEmpty)return;setState(()=>{msgs.add({'b':'0','t':x});msgs.add({'b':'1','m':'سؤال ممتاز! 💡\n\nخلينا نقسم المشكلة لخطوات صغيرة ونجرّب مثال بسيط.'});input.clear();});} @override void dispose(){input.dispose();super.dispose();} @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('المعلم الذكي',style:TextStyle(fontWeight:FontWeight.w900)),actions:[const Bot(size:40),const SizedBox(width:14)]),body:Column(children:[Expanded(child:ListView.builder(padding:const EdgeInsets.all(15),itemCount:msgs.length,itemBuilder:(_,i){final m=msgs[i];final bot=m['b']=='1';return Align(alignment:bot?Alignment.centerRight:Alignment.centerLeft,child:Container(constraints:const BoxConstraints(maxWidth:350),margin:const EdgeInsets.only(bottom:11),padding:const EdgeInsets.all(13),decoration:BoxDecoration(color:bot?const Color(0xFF102A4A):const Color(0xFF0874E1),borderRadius:BorderRadius.circular(17)),child:m['m']!=null?MarkdownBody(data:m['m']!,styleSheet:MarkdownStyleSheet(p:const TextStyle(color:Colors.white,height:1.7,fontSize:13),code:const TextStyle(fontFamily:'monospace',color:Color(0xFF8CE8FF)),codeblockDecoration:BoxDecoration(color:const Color(0xFF051225),borderRadius:BorderRadius.all(Radius.circular(12))))):Text(m['t']!,style:const TextStyle(color:Colors.white,height:1.65,fontSize:13))));})),SafeArea(top:false,child:Container(color:const Color(0xFF07172B),padding:const EdgeInsets.fromLTRB(10,7,10,9),child:Row(children:[IconButton(onPressed:(){},icon:const Icon(Icons.emoji_emotions_outlined)),Expanded(child:TextField(controller:input,textInputAction:TextInputAction.send,onSubmitted:(_)=>send(),decoration:const InputDecoration(hintText:'اكتب سؤالك هنا...',contentPadding:EdgeInsets.symmetric(horizontal:15,vertical:12)))),const SizedBox(width:6),CircleAvatar(backgroundColor:C.blue,child:IconButton(onPressed:send,icon:const Icon(Icons.send_rounded))) ]))) ])); }
}

class ProgressPage extends StatelessWidget { final bool ar; const ProgressPage({super.key,required this.ar}); @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(ar?'تقدمي':'My Progress',style:const TextStyle(fontWeight:FontWeight.w900))),body:ListView(padding:const EdgeInsets.fromLTRB(17,2,17,28),children:[CardBox(colors:const [Color(0xFF0E4380),Color(0xFF0B294E)],child:Column(children:[const Row(children:[Bot(size:60),SizedBox(width:13),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('المستوى 3',style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),Text('330 / 500 XP',style:TextStyle(fontSize:10,color:Colors.white60))]))]),const SizedBox(height:12),const ClipRRect(borderRadius:BorderRadius.all(Radius.circular(20)),child:LinearProgressIndicator(value:.66,minHeight:8,backgroundColor:Colors.white12,valueColor:AlwaysStoppedAnimation(C.cyan)))])),const SizedBox(height:13),Row(children:[Expanded(child:Stat('7',ar?'دروس مكتملة':'Lessons',Icons.menu_book_rounded)),const SizedBox(width:9),Expanded(child:Stat('12',ar?'تمرين محلول':'Exercises',Icons.fitness_center_rounded))]),const SizedBox(height:9),Row(children:[Expanded(child:Stat('5',ar?'إنجازات':'Achievements',Icons.star_rounded)),const SizedBox(width:9),Expanded(child:Stat('3',ar?'أيام متتالية':'Streak',Icons.local_fire_department_rounded))]),const SizedBox(height:21),Text(ar?'إنجازاتك':'Your achievements',style:const TextStyle(fontSize:17,fontWeight:FontWeight.w900)),const SizedBox(height:9),Ach(icon:Icons.local_fire_department_rounded,title:ar?'مبتدئ بايثون':'Python Beginner',sub:ar?'أكمل أول درس':'Complete first lesson'),Ach(icon:Icons.emoji_events_rounded,title:ar?'مُتقن الكود':'Code Master',sub:ar?'حل أول 5 تمارين':'Solve 5 exercises'),Ach(icon:Icons.rocket_launch_rounded,title:ar?'محترف المستقبل':'Future Pro',sub:ar?'الوصول للمستوى 3':'Reach level 3')])); }
}
class Stat extends StatelessWidget{final String n,l;final IconData icon;const Stat(this.n,this.l,this.icon,{super.key});@override Widget build(BuildContext context)=>CardBox(colors:const [Color(0xFF102D51),Color(0xFF0B203C)],padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:C.cyan),const SizedBox(height:9),Text(n,style:const TextStyle(fontSize:25,fontWeight:FontWeight.w900)),Text(l,style:const TextStyle(color:Colors.white54,fontSize:10))]));}
class Ach extends StatelessWidget{final IconData icon;final String title,sub;const Ach({super.key,required this.icon,required this.title,required this.sub});@override Widget build(BuildContext context)=>Container(margin:const EdgeInsets.only(bottom:9),padding:const EdgeInsets.all(11),decoration:BoxDecoration(color:const Color(0xFF0E2748),borderRadius:BorderRadius.circular(16),border:Border.all(color:const Color(0x22448FD3))),child:Row(children:[Container(width:43,height:43,decoration:const BoxDecoration(shape:BoxShape.circle,gradient:LinearGradient(colors:[Color(0xFF198CF0),Color(0xFF4C43D7)])),child:Icon(icon)),const SizedBox(width:11),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontWeight:FontWeight.w800)),Text(sub,style:const TextStyle(color:Colors.white54,fontSize:10))])),const Icon(Icons.check_circle_rounded,color:C.green,size:21)]));}

class SettingsPage extends StatelessWidget{final bool ar;const SettingsPage({super.key,required this.ar});@override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(ar?'الإعدادات':'Settings',style:const TextStyle(fontWeight:FontWeight.w900))),body:ListView(padding:const EdgeInsets.fromLTRB(17,3,17,28),children:[Setting(Icons.language_rounded,ar?'اللغة':'Language',ar?'العربية':'English'),Setting(Icons.dark_mode_rounded,ar?'المظهر':'Appearance',ar?'الوضع الداكن':'Dark mode',trailing:Switch(value:true,onChanged:(_){ })),Setting(Icons.text_fields_rounded,ar?'نوع الخط':'Font','Cairo'),Setting(Icons.code_rounded,ar?'إعدادات الكود':'Code settings','Python'),Setting(Icons.help_outline_rounded,ar?'مساعدة ودعم':'Help & Support',null),Setting(Icons.info_outline_rounded,ar?'معلومات التطبيق':'App info','1.0.0'),const SizedBox(height:18),SizedBox(height:51,child:ElevatedButton(onPressed:(){},style:ElevatedButton.styleFrom(backgroundColor:C.red,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(16))),child:Text(ar?'تسجيل الخروج':'Log out',style:const TextStyle(fontWeight:FontWeight.w900))))]));}
class Setting extends StatelessWidget{final IconData icon;final String title;final String? value;final Widget? trailing;const Setting(this.icon,this.title,this.value,{this.trailing,super.key});@override Widget build(BuildContext context)=>Container(margin:const EdgeInsets.only(bottom:9),decoration:BoxDecoration(color:const Color(0xFF0D2545),borderRadius:BorderRadius.circular(16),border:Border.all(color:const Color(0x1F4C9BDD))),child:ListTile(leading:Icon(icon,color:C.cyan),title:Text(title,style:const TextStyle(fontWeight:FontWeight.w700,fontSize:13)),subtitle:value==null?null:Text(value!,style:const TextStyle(color:Colors.white54,fontSize:10)),trailing:trailing??const Icon(Icons.chevron_left_rounded,color:Colors.white38)));}
