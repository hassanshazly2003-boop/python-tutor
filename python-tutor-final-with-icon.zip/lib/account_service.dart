import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'api_config.dart';

class AccountService {
  static String get baseUrl => ApiConfig.baseUrl;
  static const _tokenKey = 'account_token';
  static const _emailKey = 'account_email';

  static Future<void> setBaseUrl(String value) {
    return ApiConfig.setBaseUrl(value);
  }

  static Future<String?> token() async {
    final p = await SharedPreferences.getInstance();
    return p.getString(_tokenKey);
  }

  static Future<String?> email() async {
    final p = await SharedPreferences.getInstance();
    return p.getString(_emailKey);
  }

  static Future<void> saveSession(String token, String email) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_tokenKey, token);
    await p.setString(_emailKey, email);
  }

  static Future<void> logout() async {
    final p = await SharedPreferences.getInstance();
    await p.remove(_tokenKey);
    await p.remove(_emailKey);
  }

  static Future<void> register(String email, String password) async {
    _validateCredentials(email, password);
    final r = await http
        .post(
          Uri.parse('$baseUrl/auth/register'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'email': email.trim(), 'password': password}),
        )
        .timeout(const Duration(seconds: 15));
    final data = _decodeResponse(r);
    if (r.statusCode >= 400) {
      throw Exception(_detail(data, 'Registration failed'));
    }
    await saveSession(data['token'], data['email']);
  }

  static Future<void> login(String email, String password) async {
    _validateCredentials(email, password);
    final r = await http
        .post(
          Uri.parse('$baseUrl/auth/login'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'email': email.trim(), 'password': password}),
        )
        .timeout(const Duration(seconds: 15));
    final data = _decodeResponse(r);
    if (r.statusCode >= 400) {
      throw Exception(_detail(data, 'Login failed'));
    }
    await saveSession(data['token'], data['email']);
  }

  static void _validateCredentials(String email, String password) {
    if (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(email.trim())) {
      throw Exception('Enter a valid email');
    }
    if (password.length < 8) {
      throw Exception('Password must be at least 8 characters');
    }
  }

  static Map<String, dynamic> _decodeResponse(http.Response response) {
    try {
      final value = jsonDecode(response.body);
      if (value is Map<String, dynamic>) return value;
    } catch (_) {
      // The caller receives a stable message instead of a JSON parsing error.
    }
    return <String, dynamic>{};
  }

  static String _detail(Map<String, dynamic> data, String fallback) {
    final detail = data['detail'];
    return detail is String && detail.isNotEmpty ? detail : fallback;
  }
}
