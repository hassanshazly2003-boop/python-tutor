import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'account_service.dart';
import 'api_config.dart';

class PythonBackend {
  static String get baseUrl => ApiConfig.baseUrl;

  static Future<void> setBaseUrl(String value) {
    return ApiConfig.setBaseUrl(value);
  }

  static Future<Map<String, dynamic>> execute(
    String code, {
    String stdin = '',
  }) async {
    final token = await AccountService.token();
    final r = await http
        .post(
          Uri.parse('$baseUrl/execute'),
          headers: _headers(token),
          body: jsonEncode({'code': code, 'stdin': stdin}),
        )
        .timeout(const Duration(seconds: 10));
    final data = _decodeResponse(r);
    if (r.statusCode >= 400) {
      throw Exception(_detail(data, 'Execution server error'));
    }
    return Map<String, dynamic>.from(data);
  }

  static Future<String> askAI({
    required String prompt,
    required String language,
    String code = '',
    Uint8List? imageBytes,
    String imageMime = 'image/jpeg',
  }) async {
    final token = await AccountService.token();
    final body = <String, dynamic>{
      'prompt': prompt,
      'language': language,
      'code': code,
    };
    if (imageBytes != null) {
      body['image_base64'] = base64Encode(imageBytes);
      body['image_mime'] = imageMime;
    }

    final r = await http
        .post(
          Uri.parse('$baseUrl/ai'),
          headers: _headers(token),
          body: jsonEncode(body),
        )
        .timeout(const Duration(seconds: 50));

    final data = _decodeResponse(r);
    if (r.statusCode >= 400) {
      throw Exception(_detail(data, 'AI server error'));
    }
    return data['text']?.toString() ?? '';
  }

  static Map<String, String> _headers(String? token) {
    return <String, String>{
      'Content-Type': 'application/json',
      if (token != null && token.isNotEmpty) 'Authorization': 'Bearer $token',
    };
  }

  static Map<String, dynamic> _decodeResponse(http.Response response) {
    try {
      final value = jsonDecode(response.body);
      if (value is Map<String, dynamic>) return value;
    } catch (_) {
      // The caller receives a stable message instead of a JSON parsing error.
    }
    return <String, dynamic>{};
  }

  static String _detail(Map<String, dynamic> data, String fallback) {
    final detail = data['detail'];
    return detail is String && detail.isNotEmpty ? detail : fallback;
  }
}
