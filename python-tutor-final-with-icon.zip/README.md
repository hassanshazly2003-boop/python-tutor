# Python Tutor — Flutter client + Replit FastAPI backend

هذه النسخة تحافظ على ميزات التطبيق الحالية:

- محرك Python حقيقي خلف API
- مدرس AI عبر Gemini
- تحليل وتصحيح الكود
- إرسال الكود والصور للذكاء الاصطناعي
- OCR من الكاميرا
- عنوان الخادم قابل للتغيير من الإعدادات
- عربي / English
- حسابات واشتراكات Premium عبر Google Play بدون فترة تجريبية مجانية

## تشغيله على Replit

الخدمة الموجودة في `artifacts/api-server` تعمل تلقائياً عبر مسار `/api`.

1. أضف `SESSION_SECRET` عشوائياً بطول 32 حرفاً أو أكثر إلى Secrets.
2. أضف `GEMINI_API_KEY` إلى Secrets لاستخدام المدرس الذكي. لا تضعه داخل Flutter.
3. ابدأ workflow الخاص بـ `artifacts/api-server`.
4. اختبر `GET /api/healthz`.
5. عند تشغيل تطبيق Android، ابنِه باستخدام:

```bash
flutter pub get
flutter run --dart-define=API_BASE_URL=https://YOUR-REPLIT-DOMAIN/api
```

يمكن تغيير العنوان لاحقاً من Settings داخل التطبيق. العنوان يجب أن ينتهي بـ `/api`.

## تشغيل backend محلياً

من جذر المشروع:

```bash
python3 -m uvicorn main:app --app-dir artifacts/api-server/python_backend --host 0.0.0.0 --port 8080
```

لـ Android Emulator استخدم:

```text
http://10.0.2.2:8080/api
```

وللهاتف الحقيقي استخدم عنوان الجهاز الذي يشغّل backend، مثل:

```text
http://192.168.1.10:8080/api
```

## بناء APK

```bash
cd flutter_app
flutter pub get
flutter build apk --release --dart-define=API_BASE_URL=https://YOUR-REPLIT-DOMAIN/api
```

## العزل الأمني لتشغيل Python

لا يشغّل backend الكود داخل عملية الخادم مباشرة. كل طلب يمر عبر sandbox Linux منفصل:

- user/mount/PID/network/IPC/UTS namespaces
- root filesystem مؤقت يحتوي فقط على Python وNix للقراءة
- مجلد عمل مؤقت داخل tmpfs
- عزل الشبكة بدون واجهة شبكة
- حدود CPU والذاكرة وحجم الملفات وعدد الملفات والعمليات
- مهلة خارجية تقتل namespace بالكامل

إذا لم تتوفر آلية namespace، يعيد الخادم `503` ويرفض التنفيذ. لا يوجد fallback إلى subprocess عادي.

## Premium

تمت إضافة بنية Premium داخل التطبيق:

- `python_premium_monthly`
- `python_premium_yearly`
- شاشة Premium
- Restore Purchases
- تكامل `in_app_purchase`
- Demo mode محلي لاختبار الواجهة قبل إعداد Google Play Billing

قبل النشر:

1. أنشئ اشتراكين بنفس Product IDs في Google Play Console.
2. اربط أسعار الاشتراك الحقيقية.
3. اختبر License testers.
4. لا تعتمد على `premium_demo` كحماية حقيقية؛ عند النشر يجب التحقق من المشتريات من Google Play أو backend موثوق.
