from __future__ import annotations

import os
import shutil
import signal
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import TypedDict


class SandboxResult(TypedDict):
    ok: bool
    stdout: str
    stderr: str
    exit_code: int
    timed_out: bool


class SandboxUnavailable(RuntimeError):
    pass


EXECUTION_TIMEOUT_SECONDS = 5
MAX_OUTPUT_BYTES = 12_000
MAX_CODE_BYTES = 20_000


_BOOTSTRAP = r"""
host_dir="$1"
root="$2"
python_bin="$3"

mount --make-rprivate /
mount --rbind /nix "$root/nix"
mount --make-rslave "$root/nix"
mount -o remount,ro,bind "$root/nix"
mount -t tmpfs -o size=8m,nosuid,nodev,noexec tmpfs "$root/work"
mount -t tmpfs -o size=16m,nosuid,nodev,noexec tmpfs "$root/tmp"

cp "$host_dir/main.py" "$root/work/main.py"
cp "$host_dir/sandbox_child.py" "$root/work/sandbox_child.py"

status=0
chroot "$root" "$python_bin" -I /work/sandbox_child.py || status=$?

cp "$root/work/stdout.txt" "$host_dir/stdout.txt" 2>/dev/null || :
cp "$root/work/stderr.txt" "$host_dir/stderr.txt" 2>/dev/null || :
exit "$status"
"""


_CHILD = r"""
import os
import resource
import runpy
import sys
import traceback


def limit(kind, soft, hard=None):
    if hard is None:
        hard = soft
    try:
        resource.setrlimit(kind, (soft, hard))
    except (ValueError, OSError):
        pass


os.environ.clear()
os.environ["PATH"] = "/nix/store"
os.chdir("/work")

# These limits apply inside the isolated PID/mount/network namespaces.
limit(resource.RLIMIT_CPU, 2, 2)
limit(resource.RLIMIT_AS, 256 * 1024 * 1024, 256 * 1024 * 1024)
limit(resource.RLIMIT_FSIZE, 256 * 1024, 256 * 1024)
limit(resource.RLIMIT_NOFILE, 32, 32)
limit(resource.RLIMIT_CORE, 0, 0)
limit(resource.RLIMIT_STACK, 8 * 1024 * 1024, 8 * 1024 * 1024)
if hasattr(resource, "RLIMIT_NPROC"):
    limit(resource.RLIMIT_NPROC, 32, 32)

stdout = open("/work/stdout.txt", "w", encoding="utf-8", buffering=1)
stderr = open("/work/stderr.txt", "w", encoding="utf-8", buffering=1)
sys.stdout = stdout
sys.stderr = stderr

try:
    runpy.run_path("/work/main.py", run_name="__main__")
except SystemExit as exc:
    code = exc.code
    sys.exit(code if isinstance(code, int) else 1)
except BaseException:
    traceback.print_exc()
    sys.exit(1)
finally:
    stdout.flush()
    stderr.flush()
    stdout.close()
    stderr.close()
"""


def _read_limited(path: Path) -> str:
    try:
        data = path.read_bytes()[:MAX_OUTPUT_BYTES]
    except OSError:
        return ""
    text = data.decode("utf-8", errors="replace")
    if path.stat().st_size > MAX_OUTPUT_BYTES:
        text += "\n[output truncated]"
    return text


def execute_in_sandbox(code: str, stdin: str = "") -> SandboxResult:
    if len(code.encode("utf-8")) > MAX_CODE_BYTES:
        raise ValueError("Code is too large.")

    unshare = shutil.which("unshare")
    chroot = shutil.which("chroot")
    python_bin = os.path.realpath(sys.executable)
    if not unshare or not chroot or not python_bin.startswith("/nix/"):
        raise SandboxUnavailable(
            "The Linux namespace sandbox is unavailable; code execution was refused."
        )

    with tempfile.TemporaryDirectory(prefix="python-tutor-sandbox-") as temp:
        host_dir = Path(temp)
        root = host_dir / "root"
        for directory in ("nix", "work", "tmp"):
            (root / directory).mkdir(parents=True)
        (host_dir / "main.py").write_text(code, encoding="utf-8")
        (host_dir / "sandbox_child.py").write_text(_CHILD, encoding="utf-8")

        command = [
            unshare,
            "--user",
            "--map-root-user",
            "--mount",
            "--pid",
            "--fork",
            "--net",
            "--ipc",
            "--uts",
            "--kill-child=KILL",
            "/bin/sh",
            "-eu",
            "-c",
            _BOOTSTRAP,
            "sandbox-bootstrap",
            str(host_dir),
            str(root),
            python_bin,
        ]
        process = subprocess.Popen(
            command,
            stdin=subprocess.PIPE,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
            close_fds=True,
        )
        timed_out = False
        try:
            process.communicate(input=stdin.encode("utf-8"), timeout=EXECUTION_TIMEOUT_SECONDS + 3)
        except subprocess.TimeoutExpired:
            timed_out = True
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.wait(timeout=2)

        stdout = _read_limited(host_dir / "stdout.txt")
        stderr = _read_limited(host_dir / "stderr.txt")
        if timed_out:
            stderr = "Execution stopped: time limit exceeded (5 seconds)."
        elif process.returncode in (124, 137):
            stderr = "Execution stopped: CPU or resource limit exceeded."
        return {
            "ok": not timed_out and process.returncode == 0,
            "stdout": stdout,
            "stderr": stderr,
            "exit_code": -1 if timed_out else (process.returncode or 0),
            "timed_out": timed_out,
        }