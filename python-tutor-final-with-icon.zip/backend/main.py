from __future__ import annotations

import base64
import hashlib
import os
import re
import secrets
import sqlite3
import time
from pathlib import Path
from typing import Optional

import httpx
import jwt
from fastapi import APIRouter, FastAPI, Header, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, field_validator

from sandbox_runner import SandboxUnavailable, execute_in_sandbox


API_PREFIX = "/api"
BASE_DIR = Path(__file__).resolve().parents[1]
DB_PATH = Path(os.getenv("DB_PATH", str(BASE_DIR / "data" / "python_tutor.db"))).expanduser()
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

CONFIGURED_SECRET = os.getenv("JWT_SECRET") or os.getenv("SESSION_SECRET")
JWT_SECRET = CONFIGURED_SECRET or secrets.token_urlsafe(32)
JWT_ALG = "HS256"
TOKEN_TTL_SECONDS = 30 * 24 * 60 * 60
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-3.8-flash").strip()
ENVIRONMENT = os.getenv("ENVIRONMENT", "development").lower()


def db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at INTEGER NOT NULL,
            trial_started_at INTEGER NOT NULL
        )
        """
    )
    conn.commit()
    return conn


def hash_password(password: str, salt: Optional[bytes] = None) -> str:
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 210_000)
    return base64.b64encode(salt + digest).decode("ascii")


def verify_password(password: str, stored: str) -> bool:
    try:
        raw = base64.b64decode(stored.encode("ascii"))
        salt, expected = raw[:16], raw[16:]
        actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 210_000)
        return secrets.compare_digest(actual, expected)
    except (ValueError, TypeError):
        return False


def make_token(user_id: int) -> str:
    now = int(time.time())
    payload = {
        "sub": str(user_id),
        "iat": now,
        "exp": now + TOKEN_TTL_SECONDS,
        "iss": "python-tutor",
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)


def current_user(authorization: Optional[str]) -> sqlite3.Row:
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="Authentication required")
    token = authorization.split(" ", 1)[1].strip()
    try:
        payload = jwt.decode(
            token,
            JWT_SECRET,
            algorithms=[JWT_ALG],
            issuer="python-tutor",
        )
        user_id = int(payload["sub"])
    except (jwt.PyJWTError, KeyError, TypeError, ValueError):
        raise HTTPException(status_code=401, detail="Invalid or expired session")

    conn = db()
    try:
        user = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    finally:
        conn.close()
    if not user:
        raise HTTPException(status_code=401, detail="Account not found")
    return user


def error_detail(response: httpx.Response) -> str:
    try:
        payload = response.json()
        if isinstance(payload, dict):
            return str(payload.get("error", {}).get("message") or payload.get("detail") or response.text)
    except ValueError:
        pass
    return response.text[:2000]


class AuthRequest(BaseModel):
    email: str = Field(..., min_length=5, max_length=200)
    password: str = Field(..., min_length=8, max_length=200)

    @field_validator("email")
    @classmethod
    def validate_email(cls, value: str) -> str:
        value = value.strip().lower()
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", value):
            raise ValueError("Enter a valid email")
        return value


class ExecuteRequest(BaseModel):
    code: str = Field(..., min_length=1, max_length=20_000)
    stdin: str = Field("", max_length=5_000)


class AIRequest(BaseModel):
    prompt: str = Field(..., min_length=1, max_length=20_000)
    language: str = Field("ar", max_length=10)
    code: str = Field("", max_length=20_000)
    image_base64: Optional[str] = Field(None, max_length=8_000_000)
    image_mime: str = Field("image/jpeg", max_length=40)

    @field_validator("image_mime")
    @classmethod
    def validate_image_mime(cls, value: str) -> str:
        allowed = {"image/jpeg", "image/png", "image/webp"}
        if value not in allowed:
            raise ValueError("Only JPEG, PNG, and WebP images are supported")
        return value


SYSTEM_PROMPT = """You are Python Tutor inside an educational app.
Teach Python from beginner to advanced.
Answer in the user's requested language (Arabic or English).
When reviewing code: identify syntax/runtime/logic problems, explain why, give corrected code, explain the correction, and suggest one small exercise.
Never claim code was executed unless the execution endpoint actually returned a result.
Keep answers practical and educational.
"""

app = FastAPI(title="Python Tutor Backend", version="3.0.0", docs_url=f"{API_PREFIX}/docs")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        origin.strip()
        for origin in os.getenv("CORS_ORIGINS", "*").split(",")
        if origin.strip()
    ],
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Authorization", "Content-Type"],
)
router = APIRouter(prefix=API_PREFIX)


@app.on_event("startup")
def validate_configuration() -> None:
    if ENVIRONMENT == "production" and (
        not CONFIGURED_SECRET or len(CONFIGURED_SECRET) < 32
    ):
        raise RuntimeError(
            "JWT_SECRET or SESSION_SECRET must be a random value of at least 32 characters in production."
        )


@router.get("/healthz")
def health() -> dict[str, str]:
    return {"status": "ok", "service": "python-tutor"}


@router.post("/auth/register")
def register(req: AuthRequest) -> dict[str, str | int]:
    now = int(time.time())
    conn = db()
    try:
        cur = conn.execute(
            "INSERT INTO users(email,password_hash,created_at,trial_started_at) VALUES(?,?,?,?)",
            (req.email, hash_password(req.password), now, now),
        )
        conn.commit()
        user_id = int(cur.lastrowid)
    except sqlite3.IntegrityError:
        raise HTTPException(
            status_code=409, detail="An account with this email already exists"
        )
    finally:
        conn.close()
    return {
        "token": make_token(user_id),
        "token_type": "bearer",
        "email": req.email,
    }


@router.post("/auth/login")
def login(req: AuthRequest) -> dict[str, str]:
    conn = db()
    try:
        user = conn.execute(
            "SELECT * FROM users WHERE email=?", (req.email,)
        ).fetchone()
    finally:
        conn.close()
    if not user or not verify_password(req.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Incorrect email or password")
    return {"token": make_token(user["id"]), "token_type": "bearer", "email": req.email}


@router.post("/execute")
def execute(
    req: ExecuteRequest,
    authorization: Optional[str] = Header(default=None),
) -> dict[str, str | bool | int]:
    current_user(authorization)
    try:
        return execute_in_sandbox(req.code, req.stdin)
    except SandboxUnavailable as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))


@router.post("/ai")
async def ai(
    req: AIRequest,
    authorization: Optional[str] = Header(default=None),
) -> dict[str, str | bool]:
    current_user(authorization)
    if not GEMINI_API_KEY:
        raise HTTPException(
            status_code=503,
            detail="GEMINI_API_KEY is not configured on the backend.",
        )
    language = "Arabic" if req.language.lower().startswith("ar") else "English"
    parts: list[dict[str, object]] = [
        {
            "text": (
                f"{SYSTEM_PROMPT}\n\nPreferred response language: {language}\n"
                f"User request:\n{req.prompt}\n\nCode to inspect:\n{req.code}"
            )
        }
    ]
    if req.image_base64:
        clean = req.image_base64.split(",", 1)[-1]
        try:
            base64.b64decode(clean, validate=True)
        except ValueError:
            raise HTTPException(status_code=400, detail="Invalid base64 image data")
        parts.append(
            {
                "inline_data": {
                    "mime_type": req.image_mime,
                    "data": clean,
                }
            }
        )

    url = (
        "https://generativelanguage.googleapis.com/v1beta/models/"
        f"{GEMINI_MODEL}:generateContent"
    )
    payload = {
        "contents": [{"parts": parts}],
        "generationConfig": {"temperature": 0.25, "maxOutputTokens": 1800},
    }
    try:
        async with httpx.AsyncClient(timeout=45) as client:
            response = await client.post(
                url,
                headers={
                    "x-goog-api-key": GEMINI_API_KEY,
                    "Content-Type": "application/json",
                },
                json=payload,
            )
    except httpx.HTTPError:
        raise HTTPException(status_code=502, detail="Could not reach Gemini.")
    if response.status_code >= 400:
        raise HTTPException(status_code=502, detail=error_detail(response))
    try:
        data = response.json()
        text = data["candidates"][0]["content"]["parts"][0]["text"]
    except (ValueError, KeyError, IndexError, TypeError):
        raise HTTPException(status_code=502, detail="AI returned an unexpected response.")
    return {"ok": True, "text": str(text)}


app.include_router(router)